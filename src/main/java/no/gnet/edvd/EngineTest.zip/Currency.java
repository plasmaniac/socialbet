package no.gnet.edvd;

public enum Currency {
	EURO,NOK
}
