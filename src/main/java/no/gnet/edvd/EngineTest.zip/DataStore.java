package no.gnet.edvd;

import java.util.List;

public interface DataStore {
	
	public void placeBet(Bet bet);
	public void updateBet(Bet bet);
	public Bet getBet(Bet bet);
	public List<Bet> getBetsForEvent(Event event);
	public List<Bet> getBetsForEvent(int eventid);	
	public void storeEvent(Event event);
	public void updateEvent(Event event);
	
}
