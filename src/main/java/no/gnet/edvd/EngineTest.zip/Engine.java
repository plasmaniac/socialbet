package no.gnet.edvd;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Engine {
	
	public Map<Option, Double> getOddsForEvent(Event event, DataStore ds){
		List <Bet> bets = ds.getBetsForEvent(event.id);
		double totalbet = getTotalBet(bets);
		List<Option> options = event.getOptions();
		HashMap<Option, Double> oddsmap = new HashMap<Option, Double>();
		for (Iterator<Option> iterator = options.iterator(); iterator.hasNext();) {
			Option option =  iterator.next();
			oddsmap.put(option, totalbet / getTotalForOption(bets, option));
		}
		return oddsmap;
	}

	private double getTotalForOption(List<Bet> bets, Option option) {
		double tot=0.0D;
		for (Iterator<Bet> iterator = bets.iterator(); iterator.hasNext();) {
			Bet bet = iterator.next();
			if(bet.option.equals(option))
				tot+=bet.amount;
		}
		return tot;
	}

	private double getTotalBet(List <Bet> bets) {
		double tot=0.0D;
		for (Iterator<Bet> iterator = bets.iterator(); iterator.hasNext();) {
			tot+=iterator.next().amount;
		}
		return tot;
	}

}
