package no.gnet.edvd;

import java.util.List;

public abstract class Event extends Persist{
	
	public String name;
	public String description;

	public abstract List<Option> getOptions();
}
