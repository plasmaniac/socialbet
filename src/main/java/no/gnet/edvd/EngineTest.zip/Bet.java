package no.gnet.edvd;

public class Bet extends Persist{
	public Bet(Event event, Option option, double amount, Currency currency) {
		super();
		this.event = event;
		this.option = option;
		this.amount = amount;
		this.currency = currency;
	}
	public Bet(Event event, Option option, double amount, Currency currency, int id) {
		super();
		this.event = event;
		this.option = option;
		this.amount = amount;
		this.currency = currency;
		this.id=id;
	}	
	public Event event;
	public Option option;
	public double amount;
	public Currency currency;

}
