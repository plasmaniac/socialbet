package no.gnet.edvd;

import java.util.Map;
import junit.framework.Assert;
import org.junit.Test;

public class EngineTest {

	@Test
	public void testBet() {
		InMemoryDatastore imds = new InMemoryDatastore();
		Engine engine = new Engine();
		Event sitterRegjeringen = new YesNoEvent("Sitter den nye regjeringen hele perioden?");
		sitterRegjeringen.id=99;
		imds.storeEvent(sitterRegjeringen);
		StringOption yesoption = StringOption.YES(sitterRegjeringen);
		Bet yesbet = new Bet(sitterRegjeringen,yesoption,100.0,Currency.NOK);
		yesbet.id=InMemoryDatastore.inVMautoInc();
		StringOption nooption = StringOption.NO(sitterRegjeringen);
		Bet nobet = new Bet(sitterRegjeringen,nooption,200.0,Currency.NOK);
		nobet.id=InMemoryDatastore.inVMautoInc();
		imds.placeBet(yesbet);
		imds.placeBet(nobet);
		Map<Option, Double> odds = engine.getOddsForEvent(sitterRegjeringen, imds);
		Assert.assertTrue(odds.get(yesoption)==3.0);
		Assert.assertTrue(odds.get(nooption)==1.5);
		
		Event evliv = new MatchEvent("Everton", "Liverpool"); 
		evliv.id=InMemoryDatastore.inVMautoInc();
		imds.storeEvent(evliv);
		Bet liverbet = new Bet(evliv,new StringOption("Liverpool"),5000.0,Currency.NOK,InMemoryDatastore.inVMautoInc());
		Bet drawbet = new Bet(evliv,new StringOption("draw"),100.0,Currency.NOK,InMemoryDatastore.inVMautoInc());
		Bet everbet = new Bet(evliv,new StringOption("Everton"),400.0,Currency.NOK,InMemoryDatastore.inVMautoInc());
		imds.placeBets(liverbet,drawbet,everbet);
		Map<Option, Double> oddsle = engine.getOddsForEvent(evliv, imds);
		
		Assert.assertTrue(oddsle.get(new StringOption("Liverpool"))==1.1);
		Assert.assertTrue(oddsle.get(new StringOption("Everton"))==13.75D);        
		
		
		
		
	}

}
