package no.gnet.edvd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MatchEvent extends Event {

	public StringOption hometeam;
	public StringOption awayteam;
	public StringOption draw;
	
	public MatchEvent(String hometeam, String awayteam){
		this.hometeam=new StringOption(hometeam);
		this.awayteam=new StringOption(awayteam);
		draw = new StringOption("draw");
	}
	
	@Override
	public List<Option> getOptions() {
		ArrayList <Option> list = new ArrayList<Option>();
		Collections.addAll(list,hometeam,draw,awayteam);
		return list;
	}

}
