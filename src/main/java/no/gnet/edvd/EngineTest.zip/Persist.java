package no.gnet.edvd;

public class Persist {
	protected int id;
}
