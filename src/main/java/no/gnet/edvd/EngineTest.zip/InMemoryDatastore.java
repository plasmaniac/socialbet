package no.gnet.edvd;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

public class InMemoryDatastore implements DataStore {

	private Hashtable<Integer, Bet> bets;
	private Hashtable<Integer, Event> events;
	private Hashtable<Integer, Option> options;
	private Hashtable<Integer, Player> players;
	
	private static int autinc_id=0;
	
	
	public InMemoryDatastore(){
		bets = new Hashtable<Integer, Bet>();
		events= new Hashtable<Integer, Event> ();
		options= new Hashtable<Integer, Option> ();
		players= new Hashtable<Integer, Player> ();
	}
	
	@Override
	public void placeBet(Bet bet) {
		if(events.get(bet.event.id)==null){
			throw new IllegalStateException("Event " + bet.event.id + " does not exist");
		}
		bets.put(bet.id, bet);
	}
	
	
	public void placeBets(Bet... bets) {
		for (int i = 0; i < bets.length; i++) {
			placeBet(bets[i]);
		}
	}
	
	@Override
	public void updateBet(Bet bet) {
		bets.put(bet.id, bet);

	}

	@Override
	public Bet getBet(Bet bet) {
		return bets.get(bet.id);

	}


	@Override
	public void storeEvent(Event event) {
		events.put(event.id, event);

	}

	@Override
	public void updateEvent(Event event) {
		events.put(event.id, event);
	}

	@Override
	public List<Bet> getBetsForEvent(Event event) {
		return _getBets(event.id);
	}

	private List<Bet> _getBets(int eventid) {
		Enumeration<Integer> keys = bets.keys();
		List<Bet> betsForEvent = new ArrayList<Bet>();
		while (keys.hasMoreElements()) {
			Bet bet = bets.get(keys.nextElement());
			if(bet.event.id==eventid){
				betsForEvent.add(bet);
			}
		}
		return betsForEvent;
	}

	
	public static int inVMautoInc(){
		autinc_id++;
		return autinc_id;
	}
	
	@Override
	public List<Bet> getBetsForEvent(int eventid) {
		return _getBets(eventid);
	}

}
