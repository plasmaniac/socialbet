package no.gnet.edvd;

public class Player {
	public String firstname;
	public String lastname;
	public String email;
}
